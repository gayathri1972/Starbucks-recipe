import re
import PyPDF2

def extract_text_from_pdf(pdf_path):
    """
    Extract text from a PDF file.
    
    Args:
        pdf_path (str): Path to the PDF file
        
    Returns:
        str: Extracted text from the PDF
    """
    extracted_text = ""
    
    try:
        with open(pdf_path, 'rb') as file:
            pdf_reader = PyPDF2.PdfReader(file)
            
            # Extract text from each page
            for page_num in range(len(pdf_reader.pages)):
                page = pdf_reader.pages[page_num]
                page_text = page.extract_text()
                
                if page_text:
                    extracted_text += page_text + "\n\n"
    
    except Exception as e:
        raise Exception(f"Error extracting text from PDF: {str(e)}")
    
    return extracted_text

def clean_text(text):
    """
    Clean extracted text by removing unnecessary characters and formatting.
    
    Args:
        text (str): Raw extracted text
        
    Returns:
        str: Cleaned text
    """
    # Remove page numbers and headers
    text = re.sub(r'Starbucks Confidential—Internal Use Only\.', '', text)
    text = re.sub(r'Page \d+ of \d+', '', text)
    
    # Remove excessive whitespace
    text = re.sub(r'\n\s*\n', '\n\n', text)
    text = re.sub(r' +', ' ', text)
    
    # Remove footer information
    text = re.sub(r'SFS-\d+-WPS-\w+-\d+', '', text)
    
    return text.strip()
