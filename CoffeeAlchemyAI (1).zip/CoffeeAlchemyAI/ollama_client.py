import requests
import json
import time
import random

def generate_coffee_recipe(prompt, model="deepseek-r1", max_retries=3, retry_delay=2):
    """
    Generate a coffee recipe using Ollama API with the specified model.
    
    Args:
        prompt (str): The prompt to send to the model
        model (str): The model to use for generation (default: deepseek-r1)
        max_retries (int): Maximum number of retries if request fails
        retry_delay (int): Delay between retries in seconds
        
    Returns:
        str: Generated recipe text
    """
    url = "http://localhost:11434/api/generate"
    
    payload = {
        "model": model,
        "prompt": prompt,
        "stream": False,
        "options": {
            "temperature": 0.7,
            "top_p": 0.9,
            "max_tokens": 2048
        }
    }
    
    headers = {
        "Content-Type": "application/json"
    }
    
    for attempt in range(max_retries):
        try:
            response = requests.post(url, json=payload, headers=headers)
            
            if response.status_code == 200:
                result = response.json()
                return result.get("response", "")
            else:
                error_msg = f"API returned status code {response.status_code}"
                if attempt < max_retries - 1:
                    time.sleep(retry_delay)
                    continue
                else:
                    raise Exception(f"Failed to generate recipe after {max_retries} attempts. {error_msg}")
                
        except requests.exceptions.RequestException as e:
            if attempt < max_retries - 1:
                time.sleep(retry_delay)
                continue
            else:
                # If we can't connect to Ollama after retries, provide a fallback response for demo purposes
                return generate_demo_recipe(prompt)
    
    # This should not be reached due to the exceptions above, but just in case
    return generate_demo_recipe(prompt)

def generate_demo_recipe(prompt):
    """
    Generate a demo recipe when Ollama API is not available.
    This helps users test the UI without needing to run Ollama locally.
    
    Args:
        prompt (str): The prompt that would be sent to the model
        
    Returns:
        str: Generated demo recipe
    """
    # Extract key preferences from the prompt to customize the demo recipe
    roast_profile = "Medium Roast"
    if "Blonde Roast" in prompt:
        roast_profile = "Blonde Roast"
    elif "Dark Roast" in prompt:
        roast_profile = "Dark Roast"
    
    brewing_method = "Pour Over"
    brewing_methods = ["Pour Over", "French Press", "Espresso", "Cold Brew", "Drip Coffee", "AeroPress", "Chemex"]
    for method in brewing_methods:
        if method in prompt:
            brewing_method = method
            break
    
    flavor_notes = []
    possible_flavors = ["Nutty", "Chocolatey", "Fruity", "Floral", "Spicy", "Earthy", "Citrusy", "Caramel", "Berry", "Herbal"]
    for flavor in possible_flavors:
        if flavor.lower() in prompt.lower():
            flavor_notes.append(flavor)
    
    if not flavor_notes:
        flavor_notes = random.sample(possible_flavors, 2)
    
    flavor_str = ", ".join(flavor_notes)
    
    # Generate coffee names based on selected profile
    coffee_names = {
        "Blonde Roast": ["Sunrise Blend", "Morning Light", "Golden Hour", "Bright Horizons"],
        "Medium Roast": ["Balanced Harmony", "Classic Explorer", "Midday Moment", "Urban Reserve"],
        "Dark Roast": ["Midnight Magic", "Deep Roast Reserve", "Bold Expedition", "Roaster's Choice"]
    }
    
    recipe_name = random.choice(coffee_names[roast_profile])
    
    # Select appropriate coffee regions based on roast profile and flavor
    coffee_regions = {
        "Blonde Roast": ["Ethiopia", "Kenya", "Colombia", "Guatemala"],
        "Medium Roast": ["Costa Rica", "Peru", "Brazil", "Honduras"],
        "Dark Roast": ["Sumatra", "Indonesia", "Papua New Guinea", "Latin America"]
    }
    
    coffee_bean = random.choice(coffee_regions[roast_profile])
    
    # Brewing specifications based on method
    brewing_specs = {
        "Pour Over": {
            "grind": "Medium-fine grind, similar to table salt",
            "ratio": "1:16 (1g coffee to 16g water)",
            "instructions": """
1. Bring filtered water to 200°F (93°C)
2. Place filter in dripper and rinse with hot water
3. Add ground coffee and level the bed
4. Pour 50g of water and allow to bloom for 30 seconds
5. Continue pouring in slow, circular motions until you reach 320g of water
6. Allow all water to drain through (total brew time should be 2:30-3:00 minutes)
"""
        },
        "French Press": {
            "grind": "Coarse grind, similar to sea salt",
            "ratio": "1:15 (1g coffee to 15g water)",
            "instructions": """
1. Preheat the French press with hot water and discard water
2. Add ground coffee to the press
3. Pour 200°F (93°C) water to saturate all grounds and stir gently
4. Allow to bloom for 30 seconds
5. Add remaining water and place the lid on (don't plunge yet)
6. Let brew for 4 minutes
7. Slowly press the plunger down
8. Pour immediately to prevent over-extraction
"""
        },
        "Espresso": {
            "grind": "Fine grind, similar to powdered sugar",
            "ratio": "1:2 (1g coffee to 2g water)",
            "instructions": """
1. Ensure portafilter is clean and dry
2. Dose 18-20g of coffee into the portafilter
3. Distribute grounds evenly and tamp firmly with about 30 pounds of pressure
4. Lock portafilter into machine and start extraction immediately
5. Aim for a 25-30 second extraction time for a 36-40g yield
6. The shot should start with a slow drip, then develop into a steady stream with a honey-like consistency
"""
        },
        "Cold Brew": {
            "grind": "Extra coarse grind",
            "ratio": "1:8 (1g coffee to 8g water)",
            "instructions": """
1. Combine coffee and cold, filtered water in a large container
2. Stir gently to ensure all grounds are saturated
3. Cover and refrigerate for 12-18 hours
4. Strain through a coffee filter or fine-mesh sieve
5. Store concentrate in the refrigerator for up to 2 weeks
6. Dilute with water, milk, or over ice to taste (typically 1:1 ratio)
"""
        },
        "Drip Coffee": {
            "grind": "Medium grind, similar to sand",
            "ratio": "1:17 (1g coffee to 17g water)",
            "instructions": """
1. Place a paper filter in the basket of the drip machine
2. Rinse the filter with hot water and discard the rinse water
3. Add ground coffee to the filter
4. Fill the reservoir with cold, filtered water
5. Start the brewing cycle
6. Remove the carafe when brewing is complete to prevent burning
7. Serve immediately for best flavor
"""
        },
        "AeroPress": {
            "grind": "Medium-fine grind, between sand and table salt",
            "ratio": "1:15 (1g coffee to 15g water)",
            "instructions": """
1. Insert paper filter into the AeroPress cap and rinse with hot water
2. Attach cap to chamber and place on scale
3. Add ground coffee to the chamber
4. Start timer and add 200°F (93°C) water, filling to the top of the chamber
5. Stir for 10 seconds to ensure all grounds are saturated
6. Place plunger on top and pull up slightly to create vacuum
7. At 1:15, remove plunger and stir again gently
8. Reinsert plunger and slowly press down, taking about 30 seconds
9. Stop pressing once you hear a hissing sound
"""
        },
        "Chemex": {
            "grind": "Medium-coarse grind, slightly coarser than sand",
            "ratio": "1:16 (1g coffee to 16g water)",
            "instructions": """
1. Fold Chemex filter with three layers on one side, place in Chemex with thicker side against the spout
2. Rinse filter with hot water to remove paper taste and warm the Chemex, then discard rinse water
3. Add ground coffee and level the bed
4. Start timer and pour twice the weight of coffee in water (50g water for 25g coffee) for the bloom
5. Allow to bloom for 45 seconds
6. Pour water in slow, spiral motions, keeping the water level about 1⁄2 inch below the rim
7. Allow water to drain partially between pours
8. Final brew time should be between 3:30-4:30 minutes
"""
        }
    }
    
    # Generate the recipe
    recipe = f"""
# {recipe_name}

## Overview
A {flavor_str} {roast_profile} coffee experience using the {brewing_method} brewing method. This recipe highlights the natural characteristics of {coffee_bean} beans while bringing out the {flavor_str.lower()} notes.

## Ingredients
- 25g of {coffee_bean} {roast_profile} coffee beans
- 400g filtered water
- {brewing_specs[brewing_method]["ratio"]} coffee to water ratio

## Grind Size
{brewing_specs[brewing_method]["grind"]}

## Brewing Instructions
{brewing_specs[brewing_method]["instructions"]}

## Flavor Profile
This coffee features prominent {flavor_str.lower()} notes with a {'light and bright' if roast_profile == 'Blonde Roast' else 'balanced and smooth' if roast_profile == 'Medium Roast' else 'bold and rich'} body. 
{'The acidity is pronounced with a clean finish.' if roast_profile == 'Blonde Roast' else 'The acidity is balanced with a smooth finish.' if roast_profile == 'Medium Roast' else 'The acidity is low with a lingering finish.'}

## Serving Suggestion
Best enjoyed {'in the morning with breakfast' if roast_profile == 'Blonde Roast' else 'mid-day' if roast_profile == 'Medium Roast' else 'after dinner'}.
{'Consider pairing with citrus or berry flavors.' if 'Fruity' in flavor_notes or 'Citrusy' in flavor_notes else 'Pairs well with chocolate or nuts.' if 'Chocolatey' in flavor_notes or 'Nutty' in flavor_notes else 'Try with a pastry to complement the flavors.'}

*Note: This is a demonstration recipe. When Ollama is properly configured with the deepseek-r1 model, you'll receive custom AI-generated recipes.*
"""
    
    return recipe
