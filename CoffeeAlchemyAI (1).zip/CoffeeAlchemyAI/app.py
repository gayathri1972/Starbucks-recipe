import streamlit as st
import tempfile
import os
import random
import re
from pdf_processor import extract_text_from_pdf
from ollama_client import generate_coffee_recipe
from coffee_knowledge import extract_coffee_knowledge, get_coffee_regions_info, get_roast_profiles_info, get_brewing_methods_info, get_processing_methods_info
from coffee_image_generator import generate_starbucks_coffee_art

# Set page configuration with improved styling
st.set_page_config(
    page_title="Starbucks Coffee Recipe Generator",
    page_icon="☕",
    layout="wide"
)

# Custom CSS for better visual appearance
st.markdown("""
<style>
    .main-title {
        font-size: 3rem !important;
        font-weight: 700 !important;
        margin-bottom: 1rem !important;
        color: #6F4E37 !important;
        text-align: center;
    }
    .subtitle {
        font-size: 1.2rem !important;
        margin-bottom: 2rem !important;
        text-align: center;
        color: #5e5e5e;
    }
    .recipe-title {
        font-size: 2rem !important;
        font-weight: 600 !important;
        color: #6F4E37 !important;
        border-bottom: 2px solid #6F4E37;
        padding-bottom: 0.5rem;
        margin-bottom: 1rem !important;
    }
    .section-header {
        font-size: 1.5rem !important;
        font-weight: 600 !important;
        color: #6F4E37 !important;
        margin-top: 1.5rem !important;
    }
    .coffee-card {
        background-color: #f8f9fa;
        border-radius: 10px;
        padding: 20px;
        margin-bottom: 20px;
        border-left: 5px solid #6F4E37;
    }
    .stButton>button {
        background-color: #006241 !important; /* Starbucks green */
        color: white !important;
        font-weight: bold !important;
        padding: 0.5rem 2rem !important;
        border-radius: 30px !important;
        border: none !important;
        width: 100% !important;
    }
    .stButton>button:hover {
        background-color: #004E34 !important; /* Darker Starbucks green */
        border: none !important;
    }
    .info-text {
        font-size: 0.9rem !important;
        color: #666;
        font-style: italic;
    }
    .stExpander {
        border-radius: 10px !important;
        border: 1px solid #ddd !important;
    }
</style>
""", unsafe_allow_html=True)

# Starbucks coffee images for visual appeal
COFFEE_IMAGES = {
    "Blonde Roast": "https://globalassets.starbucks.com/assets/594ffeee6d4c4517a977c269c1842ce6.jpg",
    "Medium Roast": "https://globalassets.starbucks.com/assets/80d88a9bc19645c6a02cb7f9912f7716.jpg",
    "Dark Roast": "https://globalassets.starbucks.com/assets/0f7b291e3d6840d19af5e0bc2af3197f.jpg"
}

# Starbucks logo
STARBUCKS_LOGO = "https://upload.wikimedia.org/wikipedia/en/thumb/d/d3/Starbucks_Corporation_Logo_2011.svg/800px-Starbucks_Corporation_Logo_2011.svg.png"

# Coffee quotes for a nice touch
COFFEE_QUOTES = [
    '"Coffee is a language in itself." – Jackie Chan',
    '"Coffee is a lot more than just a drink; it\'s something happening." – Gertrude Stein',
    '"Life begins after coffee." – Unknown',
    '"Coffee first. Schemes later." – Leanna Renee Hieber',
    '"Coffee is a hug in a mug." – Unknown',
    '"Coffee: the favorite drink of the civilized world." – Thomas Jefferson',
    '"Science may never come up with a better office communication system than the coffee break." – Earl Wilson',
    '"I believe humans get a lot done, not because we\'re smart, but because we have thumbs so we can make coffee." – Flash Rosenberg',
    '"To me, the smell of fresh-made coffee is one of the greatest inventions." – Hugh Jackman',
    '"Coffee is the common man\'s gold, and like gold, it brings to every person the feeling of luxury and nobility." – Sheik-Abd-al-Kadir'
]

def create_recipe_prompt(preferences, coffee_knowledge):
    """Create a prompt for the deepseek-r1 model based on user preferences and coffee knowledge."""
    prompt = f"""
    You are a professional Starbucks barista and coffee expert with extensive knowledge about Starbucks coffee cultivation, roasting, and brewing techniques. 
    Create a detailed, precise Starbucks-style coffee recipe based on these exact preferences:
    
    Roast Profile: {preferences['roast_profile']}
    Flavor Notes Desired: {preferences['flavor_notes']}
    Brewing Method: {preferences['brewing_method']}
    Additional Preferences: {preferences['additional_preferences']}
    
    Use this coffee knowledge to enhance your recipe, but make sure it follows Starbucks style and standards:
    {coffee_knowledge}
    
    The Starbucks recipe MUST include all of the following sections:
    
    1. RECIPE NAME: Create an appealing, creative name for this coffee recipe that reflects its character
    
    2. OVERVIEW: A brief description of the recipe and what makes it special (2-3 sentences)
    
    3. COFFEE SELECTION: 
       - Recommend specific coffee bean origins that would highlight the desired flavor notes
       - Specify the recommended roast level and processing method
    
    4. INGREDIENTS:
       - Exact coffee amount in grams
       - Exact water amount in grams or milliliters
       - Water-to-coffee ratio
       - Any additional ingredients if appropriate
    
    5. GRIND SIZE: Precise grind size recommendation for the brewing method (be specific)
    
    6. EQUIPMENT NEEDED: List all required equipment
    
    7. BREWING INSTRUCTIONS:
       - Detailed step-by-step instructions with exact timing for each step
       - Temperature specifications
       - Pouring technique if applicable
       - Total brew time
    
    8. FLAVOR PROFILE:
       - Detailed description of expected flavor notes, acidity, body, and aftertaste
       - How the brewing method enhances specific characteristics
    
    9. SERVING SUGGESTIONS:
       - Recommended drinking temperature
       - Pairing suggestions
       - Any garnish or addition recommendations
    
    Format the recipe in Markdown syntax with clear headings for each section.
    Focus on precision, clarity, and professional expertise.
    """
    return prompt

def main():
    # Display Starbucks logo above the title
    st.markdown(f'<div style="text-align: center; margin-bottom: 20px;"><img src="{STARBUCKS_LOGO}" width="120" alt="Starbucks Logo" /></div>', unsafe_allow_html=True)
    
    # Display title with custom styling
    st.markdown('<div class="main-title">☕ Starbucks Recipe Creator</div>', unsafe_allow_html=True)
    st.markdown('<div class="subtitle">Create custom Starbucks-style coffee recipes tailored to your preferences using AI</div>', unsafe_allow_html=True)
    
    # Display a random coffee quote
    quote = random.choice(COFFEE_QUOTES)
    st.markdown(f'<div style="text-align: center; padding: 10px; margin-bottom: 30px; font-style: italic; color: #5D4037;">{quote}</div>', unsafe_allow_html=True)
    
    # Initialize session state for coffee knowledge - automatically load it
    if 'coffee_knowledge' not in st.session_state:
        try:
            # Automatically extract knowledge from the included PDF
            pdf_path = "attached_assets/WPS-Barista-Training-Guidebook-Brewed.pdf"
            if os.path.exists(pdf_path):
                extracted_text = extract_text_from_pdf(pdf_path)
                coffee_knowledge = extract_coffee_knowledge(extracted_text)
                regions_info = get_coffee_regions_info(extracted_text)
                roast_profiles_info = get_roast_profiles_info(extracted_text)
                brewing_methods_info = get_brewing_methods_info(extracted_text)
                processing_methods_info = get_processing_methods_info(extracted_text)
                
                st.session_state.coffee_knowledge = coffee_knowledge
                st.session_state.regions_info = regions_info
                st.session_state.roast_profiles_info = roast_profiles_info
                st.session_state.brewing_methods_info = brewing_methods_info
                st.session_state.processing_methods_info = processing_methods_info
                st.session_state.pdf_processed = True
            else:
                # Fallback if PDF doesn't exist
                st.session_state.coffee_knowledge = "Coffee knowledge from a professional barista training guide."
                st.session_state.pdf_processed = True 
                st.session_state.regions_info = ""
                st.session_state.roast_profiles_info = ""
                st.session_state.brewing_methods_info = ""
                st.session_state.processing_methods_info = ""
        except Exception as e:
            # Ensure we can still use the app even if PDF processing fails
            st.session_state.coffee_knowledge = "Coffee knowledge from a professional barista training guide."
            st.session_state.pdf_processed = True
            st.session_state.regions_info = ""
            st.session_state.roast_profiles_info = ""
            st.session_state.brewing_methods_info = ""
            st.session_state.processing_methods_info = ""
    
    # App tabs - Prioritize the AI generator aspect
    tab1, tab2 = st.tabs(["Starbucks Recipe Creator", "About Starbucks"])
    
    with tab1:
        st.header("Create Your Custom Starbucks Recipe")
        
        # User preferences input in a nice card
        st.markdown('<div class="coffee-card">', unsafe_allow_html=True)
        st.markdown('<h3 style="color: #006241; margin-bottom: 20px;">Your Starbucks Preferences</h3>', unsafe_allow_html=True)
        
        col1, col2 = st.columns(2)
        
        with col1:
            # Roast profile with visual icon
            roast_profile = st.selectbox(
                "Roast Profile", 
                ["Blonde Roast", "Medium Roast", "Dark Roast"],
                help="Select your preferred coffee roast level"
            )
            
            # Display the corresponding bean image
            st.markdown(f'<div style="text-align: center;"><img src="{COFFEE_IMAGES[roast_profile]}" width="60" alt="{roast_profile}" /><br><small>{roast_profile}</small></div>', unsafe_allow_html=True)
            
            brewing_method = st.selectbox(
                "Brewing Method",
                ["Pour Over", "French Press", "Espresso", "Cold Brew", "Drip Coffee", "AeroPress", "Chemex"],
                help="Choose your brewing method"
            )
        
        with col2:
            flavor_notes = st.multiselect(
                "Desired Flavor Notes",
                ["Nutty", "Chocolatey", "Fruity", "Floral", "Spicy", "Earthy", "Citrusy", "Caramel", "Berry", "Herbal"],
                help="Select the flavor notes you'd like in your coffee"
            )
            
            # Stylized display of selected flavor notes
            if flavor_notes:
                flavor_html = ""
                for note in flavor_notes:
                    flavor_html += f'<span style="display: inline-block; background-color: rgba(111, 78, 55, 0.2); border-radius: 15px; padding: 5px 10px; margin: 3px; font-size: 0.8rem;">{note}</span>'
                st.markdown(f'<div style="margin: 10px 0;">{flavor_html}</div>', unsafe_allow_html=True)
            
            additional_preferences = st.text_area(
                "Additional Preferences",
                placeholder="E.g., I prefer low acidity, want something strong for the morning, etc.",
                help="Add any additional preferences or requirements"
            )
        
        st.markdown('</div>', unsafe_allow_html=True)
        
        # Convert multiselect to string
        flavor_notes_str = ", ".join(flavor_notes) if flavor_notes else "Balanced"
        
        # Generate recipe button - Starbucks green
        col1, col2, col3 = st.columns([1, 2, 1])
        with col2:
            generate_button = st.button("Create Starbucks Recipe", use_container_width=True)
        
        if generate_button:
            if not flavor_notes:
                st.warning("Please select at least one flavor note.")
            else:
                preferences = {
                    "roast_profile": roast_profile,
                    "flavor_notes": flavor_notes_str,
                    "brewing_method": brewing_method,
                    "additional_preferences": additional_preferences
                }
                
                with st.spinner("Our Starbucks baristas are crafting your custom recipe..."):
                    # Create prompt for recipe generation
                    prompt = create_recipe_prompt(preferences, st.session_state.coffee_knowledge)
                    
                    # Generate recipe using Ollama
                    try:
                        recipe = generate_coffee_recipe(prompt)
                        
                        st.success("Your custom Starbucks recipe is ready!")
                        
                        # Extract recipe name from the markdown text
                        recipe_name = "Starbucks Coffee"  # default name
                        try:
                            # Try to extract the recipe name from the markdown
                            name_match = re.search(r'#\s*(.*?)(?:\n|$)', recipe)
                            if name_match:
                                recipe_name = name_match.group(1).strip()
                            else:
                                # Alternative pattern: look for RECIPE NAME: section
                                name_match = re.search(r'RECIPE NAME:?\s*(.*?)(?:\n|$)', recipe, re.IGNORECASE)
                                if name_match:
                                    recipe_name = name_match.group(1).strip()
                        except Exception as e:
                            st.warning(f"Could not extract recipe name: {str(e)}")
                        
                        # Generate coffee image based on recipe
                        coffee_image = generate_starbucks_coffee_art(
                            recipe_name,
                            preferences["roast_profile"],
                            preferences["brewing_method"]
                        )
                        
                        # Display Starbucks logo above the recipe
                        st.markdown(f'<div style="text-align: center; margin: 20px 0;"><img src="{STARBUCKS_LOGO}" width="80" alt="Starbucks Logo" /></div>', unsafe_allow_html=True)
                        
                        # Display the recipe in a nice format with custom styling
                        st.markdown('<div class="recipe-title">Your Custom Starbucks Recipe</div>', unsafe_allow_html=True)
                        
                        # Display the generated coffee image
                        st.markdown(f'<div style="text-align: center; margin: 20px 0;"><img src="{coffee_image}" width="400" alt="{recipe_name}" style="border-radius: 10px; box-shadow: 0 4px 8px rgba(0,0,0,0.1);" /></div>', unsafe_allow_html=True)
                        
                        # Add a decorative divider
                        st.markdown('<div style="text-align: center; margin-bottom: 20px;">☕ • ☕ • ☕</div>', unsafe_allow_html=True)
                        
                        # Display the recipe in a styled card
                        st.markdown('<div class="coffee-card">', unsafe_allow_html=True)
                        st.markdown(recipe)
                        st.markdown('</div>', unsafe_allow_html=True)
                        
                        # Add a note about downloading or sharing
                        st.markdown('<div style="text-align: center; margin-top: 20px; font-size: 0.9rem; color: #5D4037;">You can take a screenshot to save your recipe!</div>', unsafe_allow_html=True)
                        
                    except Exception as e:
                        st.error(f"Error generating recipe: {str(e)}")
                        st.info("""
                        **Note:** This application requires Ollama to be running locally with the deepseek-r1 model installed.
                        
                        To set up Ollama:
                        1. Install Ollama from [ollama.ai](https://ollama.ai)
                        2. Run Ollama and pull the deepseek-r1 model: `ollama pull deepseek-r1`
                        3. Ensure Ollama is running in the background
                        """)
    
    with tab2:
        # About This Application
        st.markdown('<div class="main-title" style="font-size: 2.2rem;">About This Application</div>', unsafe_allow_html=True)
        
        # Display all three coffee beans in a row
        bean_html = ""
        for roast in ["Blonde Roast", "Medium Roast", "Dark Roast"]:
            bean_html += f'<img src="{COFFEE_IMAGES[roast]}" width="40" style="margin: 0 10px;" alt="{roast}" />'
        
        st.markdown(f'<div style="text-align: center; margin-bottom: 20px;">{bean_html}</div>', unsafe_allow_html=True)
        
        # About content in a coffee card
        st.markdown('<div class="coffee-card">', unsafe_allow_html=True)
        st.write("""
        This Starbucks Recipe Creator uses the power of Ollama's deepseek-r1 model combined with 
        professional barista knowledge to generate authentic Starbucks-style coffee recipes tailored to your preferences.
        
        Experience the craft of Starbucks coffee creation at home with our AI-powered recipe generator that 
        combines deep coffee knowledge with your personal taste preferences to create a custom 
        Starbucks recipe just for you.
        """)
        st.markdown('</div>', unsafe_allow_html=True)
        
        # How it works section with visual styling
        st.markdown('<div class="section-header">How It Works</div>', unsafe_allow_html=True)
        
        # Process steps in styled cards
        col1, col2 = st.columns(2)
        
        with col1:
            st.markdown('<div class="coffee-card" style="height: 180px;">', unsafe_allow_html=True)
            st.markdown('##### Step 1: Define Your Starbucks Experience')
            st.write("Choose from Starbucks roast profiles, select your preferred brewing method, and pick flavor notes that match your ideal Starbucks coffee.")
            st.markdown('</div>', unsafe_allow_html=True)
            
            st.markdown('<div class="coffee-card" style="height: 180px;">', unsafe_allow_html=True)
            st.markdown('##### Step 3: Discover Your Signature Starbucks Recipe')
            st.write("Our AI barista creates a complete Starbucks-inspired recipe with precise ingredients, professional brewing instructions, and serving suggestions.")
            st.markdown('</div>', unsafe_allow_html=True)
            
        with col2:
            st.markdown('<div class="coffee-card" style="height: 180px;">', unsafe_allow_html=True)
            st.markdown('##### Step 2: Create Your Recipe')
            st.write("Click the 'Create Starbucks Recipe' button to activate our AI barista. It will craft a personalized Starbucks-style recipe just for you.")
            st.markdown('</div>', unsafe_allow_html=True)
            
            st.markdown('<div class="coffee-card" style="height: 180px;">', unsafe_allow_html=True)
            st.markdown('##### Step 4: Enjoy Your Starbucks At Home')
            st.write("Follow the detailed instructions to recreate the Starbucks experience in your own kitchen. Each recipe captures the essence of Starbucks quality.")
            st.markdown('</div>', unsafe_allow_html=True)
        
        # Features section
        st.markdown('<div class="section-header">Features</div>', unsafe_allow_html=True)
        
        features_col1, features_col2, features_col3 = st.columns(3)
        
        with features_col1:
            st.markdown('<div class="coffee-card" style="height: 150px; text-align: center;">', unsafe_allow_html=True)
            st.markdown('##### Starbucks Experience')
            st.write("Create the authentic taste of Starbucks coffee in your own home")
            st.markdown('</div>', unsafe_allow_html=True)
            
        with features_col2:
            st.markdown('<div class="coffee-card" style="height: 150px; text-align: center;">', unsafe_allow_html=True)
            st.markdown('##### Barista-Level Instructions')
            st.write("Follow professional Starbucks-style brewing techniques with precision")
            st.markdown('</div>', unsafe_allow_html=True)
            
        with features_col3:
            st.markdown('<div class="coffee-card" style="height: 150px; text-align: center;">', unsafe_allow_html=True)
            st.markdown('##### AI Craft Coffee')
            st.write("Powered by Starbucks knowledge and advanced AI technology")
            st.markdown('</div>', unsafe_allow_html=True)
        
        # Technologies Used section
        st.markdown('<div class="section-header">Technologies Used</div>', unsafe_allow_html=True)
        tech_col1, tech_col2 = st.columns(2)
        
        with tech_col1:
            st.markdown('<div class="coffee-card">', unsafe_allow_html=True)
            st.markdown('##### Streamlit')
            st.write("Interactive web interface")
            st.markdown('</div>', unsafe_allow_html=True)
            
        with tech_col2:
            st.markdown('<div class="coffee-card">', unsafe_allow_html=True)
            st.markdown('##### Ollama deepseek-r1')
            st.write("Advanced AI model for recipe generation")
            st.markdown('</div>', unsafe_allow_html=True)
        
        # Coffee Knowledge Reference with better styling
        st.markdown('<div class="section-header">Coffee Knowledge Reference</div>', unsafe_allow_html=True)
        
        # Explanation of the knowledge base
        st.markdown('<div class="info-text" style="margin-bottom: 20px;">Expand the sections below to explore coffee knowledge extracted from a professional barista training guide.</div>', unsafe_allow_html=True)
        
        # Display coffee regions information
        if hasattr(st.session_state, 'regions_info') and st.session_state.regions_info:
            with st.expander("☕ Coffee Growing Regions"):
                st.markdown(st.session_state.regions_info)
        
        # Display roast profiles information
        if hasattr(st.session_state, 'roast_profiles_info') and st.session_state.roast_profiles_info:
            with st.expander("🔥 Coffee Roast Profiles"):
                st.markdown(st.session_state.roast_profiles_info)
                
        # Display brewing methods information
        if hasattr(st.session_state, 'brewing_methods_info') and st.session_state.brewing_methods_info:
            with st.expander("⏱ Coffee Brewing Methods"):
                st.markdown(st.session_state.brewing_methods_info)
                
        # Display processing methods information
        if hasattr(st.session_state, 'processing_methods_info') and st.session_state.processing_methods_info:
            with st.expander("🌱 Coffee Processing Methods"):
                st.markdown(st.session_state.processing_methods_info)
        
        # Footer with Starbucks styling
        st.markdown('<div style="text-align: center; margin-top: 50px; padding: 20px; background-color: #006241; color: white; font-size: 0.8rem; border-radius: 5px;">', unsafe_allow_html=True)
        st.markdown(f'<img src="{STARBUCKS_LOGO}" width="30" style="margin-bottom: 10px;" /><br>', unsafe_allow_html=True)
        st.markdown('Starbucks Recipe Creator • Powered by deepseek-r1 model<br>© 2025 Starbucks Coffee Recipe Generator', unsafe_allow_html=True)
        st.markdown('</div>', unsafe_allow_html=True)

if __name__ == "__main__":
    main()
