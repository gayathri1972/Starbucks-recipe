"""
Coffee Image Generator
This module generates SVG images of coffee based on recipe parameters.
"""

import random
import base64
from io import BytesIO

def generate_coffee_svg(recipe_params):
    """
    Generate an SVG image of coffee based on recipe parameters.
    
    Args:
        recipe_params (dict): A dictionary containing recipe parameters like:
            - roast_profile: The roast profile (e.g., "Blonde Roast", "Medium Roast", "Dark Roast")
            - brewing_method: The brewing method (e.g., "Pour Over", "Espresso")
            - flavor_notes: Comma-separated string of flavor notes
    
    Returns:
        str: Base64 encoded SVG image that can be displayed in HTML
    """
    roast_profile = recipe_params.get('roast_profile', 'Medium Roast')
    brewing_method = recipe_params.get('brewing_method', 'Pour Over')
    
    # Define colors based on roast profile
    coffee_colors = {
        'Blonde Roast': '#BE9E7F',
        'Medium Roast': '#8B5A2B',
        'Dark Roast': '#5D4037'
    }
    
    cup_color = coffee_colors.get(roast_profile, '#8B5A2B')
    
    # Define cup and content style based on brewing method
    cup_styles = {
        'Espresso': {'cup_height': 80, 'cup_width': 70, 'has_handle': True, 'has_foam': True, 'foam_height': 10},
        'Pour Over': {'cup_height': 100, 'cup_width': 80, 'has_handle': True, 'has_foam': False, 'foam_height': 0},
        'French Press': {'cup_height': 110, 'cup_width': 90, 'has_handle': True, 'has_foam': True, 'foam_height': 15},
        'Cold Brew': {'cup_height': 130, 'cup_width': 70, 'has_handle': False, 'has_foam': False, 'foam_height': 0, 'has_ice': True},
        'Drip Coffee': {'cup_height': 100, 'cup_width': 80, 'has_handle': True, 'has_foam': False, 'foam_height': 0},
        'AeroPress': {'cup_height': 90, 'cup_width': 75, 'has_handle': True, 'has_foam': True, 'foam_height': 8},
        'Chemex': {'cup_height': 95, 'cup_width': 85, 'has_handle': True, 'has_foam': False, 'foam_height': 0}
    }
    
    style = cup_styles.get(brewing_method, cup_styles['Pour Over'])
    
    # Base SVG template
    svg = f"""
    <svg width="300" height="300" xmlns="http://www.w3.org/2000/svg">
        <!-- Background - Starbucks themed green circle -->
        <circle cx="150" cy="150" r="140" fill="#f0f4f0" />
        <circle cx="150" cy="150" r="130" fill="#f8fbf8" />
        
        <!-- Starbucks logo watermark -->
        <text x="150" y="40" font-family="Arial" font-size="14" fill="#006241" text-anchor="middle" font-style="italic">Starbucks Recipe</text>
    """
    
    # Add cup outline
    cup_x = 150 - (style['cup_width'] / 2)
    cup_y = 150 - (style['cup_height'] / 2)
    
    # Draw cup
    svg += f"""
        <!-- Cup -->
        <rect x="{cup_x}" y="{cup_y}" width="{style['cup_width']}" height="{style['cup_height']}" rx="5" ry="5" fill="white" stroke="#DDD" stroke-width="3" />
    """
    
    # Add handle if needed
    if style.get('has_handle', True):
        handle_x = cup_x + style['cup_width']
        handle_y = cup_y + 20
        handle_height = style['cup_height'] - 40
        
        svg += f"""
        <!-- Cup handle -->
        <path d="M {handle_x} {handle_y} 
                 C {handle_x + 20} {handle_y}, {handle_x + 20} {handle_y + handle_height}, {handle_x} {handle_y + handle_height}" 
              fill="none" stroke="#DDD" stroke-width="3" />
        """
    
    # Coffee content
    content_height = style['cup_height'] - 20
    foam_height = style.get('foam_height', 0)
    liquid_height = content_height - foam_height
    
    svg += f"""
        <!-- Coffee liquid -->
        <rect x="{cup_x + 5}" y="{cup_y + 10}" width="{style['cup_width'] - 10}" height="{liquid_height}" rx="3" ry="3" fill="{cup_color}" />
    """
    
    # Add foam if needed
    if style.get('has_foam', False) and foam_height > 0:
        foam_y = cup_y + 10
        
        svg += f"""
        <!-- Coffee foam -->
        <rect x="{cup_x + 5}" y="{foam_y}" width="{style['cup_width'] - 10}" height="{foam_height}" rx="3" ry="3" fill="#E6D2B5" />
        """
    
    # Add ice cubes for cold brew
    if style.get('has_ice', False):
        # Add a few ice cubes
        for i in range(3):
            ice_size = random.randint(10, 15)
            ice_x = cup_x + 10 + random.randint(0, style['cup_width'] - 30)
            ice_y = cup_y + 15 + random.randint(0, liquid_height - 30)
            
            svg += f"""
            <!-- Ice cube -->
            <rect x="{ice_x}" y="{ice_y}" width="{ice_size}" height="{ice_size}" rx="2" ry="2" fill="rgba(255, 255, 255, 0.7)" />
            """
    
    # Add steam for hot coffees
    if brewing_method != 'Cold Brew':
        steam_x = cup_x + style['cup_width'] / 2
        steam_y = cup_y
        
        # Multiple steam wisps
        for i in range(3):
            offset = (i - 1) * 10
            svg += f"""
            <!-- Steam wisp -->
            <path d="M {steam_x + offset} {steam_y} 
                     C {steam_x + offset - 10} {steam_y - 15}, {steam_x + offset + 10} {steam_y - 30}, {steam_x + offset} {steam_y - 45}" 
                  fill="none" stroke="#DDD" stroke-width="2" opacity="0.7" />
            """
    
    # Add recipe label
    roast_label = roast_profile.split()[0]
    brewing_label = brewing_method
    
    svg += f"""
        <!-- Recipe label -->
        <text x="150" y="260" font-family="Arial" font-size="16" fill="#006241" text-anchor="middle" font-weight="bold">{roast_label} {brewing_label}</text>
    """
    
    # Close SVG
    svg += """
    </svg>
    """
    
    # Convert SVG to base64 for HTML embedding
    svg_bytes = svg.encode('utf-8')
    b64 = base64.b64encode(svg_bytes).decode('utf-8')
    
    return f"data:image/svg+xml;base64,{b64}"


def generate_starbucks_coffee_art(recipe_name, roast_profile, brewing_method):
    """
    Generate a more artistic Starbucks-style coffee image.
    
    Args:
        recipe_name (str): Name of the recipe
        roast_profile (str): Roast profile
        brewing_method (str): Brewing method
    
    Returns:
        str: Base64 encoded SVG image
    """
    # Define coffee color based on roast level
    coffee_colors = {
        'Blonde Roast': '#BE9E7F',
        'Medium Roast': '#8B5A2B',
        'Dark Roast': '#5D4037'
    }
    coffee_color = coffee_colors.get(roast_profile, '#8B5A2B')
    
    # Create artistic SVG
    svg = f"""
    <svg width="500" height="400" xmlns="http://www.w3.org/2000/svg">
        <!-- Background with soft gradient -->
        <linearGradient id="bgGradient" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stop-color="#f9f9f9" />
            <stop offset="100%" stop-color="#e6f2ef" />
        </linearGradient>
        <rect width="500" height="400" fill="url(#bgGradient)" />
        
        <!-- Starbucks gradient background -->
        <linearGradient id="starbucksGradient" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stop-color="#f7f7f7" />
            <stop offset="100%" stop-color="#e6f2ef" />
        </linearGradient>
        <rect width="500" height="400" rx="10" ry="10" fill="url(#starbucksGradient)" stroke="#e0e0e0" stroke-width="1" />
        
        <!-- Subtle Starbucks pattern background -->
        <pattern id="starbucksPattern" patternUnits="userSpaceOnUse" width="60" height="60" patternTransform="rotate(45)">
            <path d="M 0 0 L 10 0 L 10 10 L 0 10 Z" fill="#006241" fill-opacity="0.03" />
        </pattern>
        <rect width="500" height="400" fill="url(#starbucksPattern)" />
        
        <!-- Roast Profile Representation -->
        <g transform="translate(40, 65)">
    """
    
    # Roast profile visualization
    if roast_profile == "Blonde Roast":
        svg += """
            <!-- Blonde Roast Bean Visualization -->
            <text x="0" y="-15" font-family="Arial" font-size="12" fill="#666" font-weight="bold">Blonde Roast Profile</text>
            <rect x="0" y="0" width="100" height="15" rx="7" ry="7" fill="#e0e0e0" />
            <rect x="0" y="0" width="85" height="15" rx="7" ry="7" fill="#BE9E7F" />
            <text x="110" y="12" font-family="Arial" font-size="11" fill="#666">Light, Gentle</text>
            
            <!-- Blonde Roast Bean Images -->
            <g transform="translate(0, 30)">
                <ellipse cx="10" cy="10" rx="8" ry="10" fill="#D2B48C" />
                <ellipse cx="30" cy="10" rx="8" ry="10" fill="#CDAA7D" />
                <ellipse cx="50" cy="10" rx="8" ry="10" fill="#C8B48A" />
                <text x="70" y="14" font-family="Arial" font-size="10" fill="#666">Light Brown Beans</text>
            </g>
            
            <!-- Flavor Profile for Blonde -->
            <text x="0" y="65" font-family="Arial" font-size="10" fill="#666">Flavor Notes: Subtle, Bright, Gentle Acidity</text>
        """
    elif roast_profile == "Medium Roast":
        svg += """
            <!-- Medium Roast Bean Visualization -->
            <text x="0" y="-15" font-family="Arial" font-size="12" fill="#666" font-weight="bold">Medium Roast Profile</text>
            <rect x="0" y="0" width="100" height="15" rx="7" ry="7" fill="#e0e0e0" />
            <rect x="0" y="0" width="50" height="15" rx="7" ry="7" fill="#8B5A2B" />
            <text x="110" y="12" font-family="Arial" font-size="11" fill="#666">Balanced</text>
            
            <!-- Medium Roast Bean Images -->
            <g transform="translate(0, 30)">
                <ellipse cx="10" cy="10" rx="8" ry="10" fill="#A0522D" />
                <ellipse cx="30" cy="10" rx="8" ry="10" fill="#8B4513" />
                <ellipse cx="50" cy="10" rx="8" ry="10" fill="#954535" />
                <text x="70" y="14" font-family="Arial" font-size="10" fill="#666">Medium Brown Beans</text>
            </g>
            
            <!-- Flavor Profile for Medium -->
            <text x="0" y="65" font-family="Arial" font-size="10" fill="#666">Flavor Notes: Balanced, Caramel, Nutty</text>
        """
    else:  # Dark Roast
        svg += """
            <!-- Dark Roast Bean Visualization -->
            <text x="0" y="-15" font-family="Arial" font-size="12" fill="#666" font-weight="bold">Dark Roast Profile</text>
            <rect x="0" y="0" width="100" height="15" rx="7" ry="7" fill="#e0e0e0" />
            <rect x="0" y="0" width="15" height="15" rx="7" ry="7" fill="#5D4037" />
            <text x="110" y="12" font-family="Arial" font-size="11" fill="#666">Bold, Intense</text>
            
            <!-- Dark Roast Bean Images -->
            <g transform="translate(0, 30)">
                <ellipse cx="10" cy="10" rx="8" ry="10" fill="#5D4037" />
                <ellipse cx="30" cy="10" rx="8" ry="10" fill="#4E342E" />
                <ellipse cx="50" cy="10" rx="8" ry="10" fill="#3E2723" />
                <text x="70" y="14" font-family="Arial" font-size="10" fill="#666">Dark Brown Beans</text>
            </g>
            
            <!-- Flavor Profile for Dark -->
            <text x="0" y="65" font-family="Arial" font-size="10" fill="#666">Flavor Notes: Bold, Smoky, Chocolate</text>
        """
    
    # Continue with the cup visualization
    svg += """
        </g>
        
        <!-- Coffee cup gradients -->
        <linearGradient id="cupGradient" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stop-color="#ffffff" />
            <stop offset="100%" stop-color="#f0f0f0" />
        </linearGradient>
        <linearGradient id="cupShadow" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stop-color="#ffffff" stop-opacity="0" />
            <stop offset="100%" stop-color="#aaaaaa" stop-opacity="0.2" />
        </linearGradient>
    """
    
    # Different cup shapes based on brewing method
    if brewing_method == "Espresso":
        svg += f"""
        <!-- Brewing Method Label -->
        <text x="250" y="130" font-family="Arial" font-size="14" fill="#006241" font-weight="bold" text-anchor="middle">Espresso</text>
        
        <!-- Espresso cup -->
        <ellipse cx="250" cy="210" rx="45" ry="15" fill="url(#cupGradient)" stroke="#ddd" stroke-width="2" />
        <path d="M 205 210 C 205 245, 295 245, 295 210" fill="url(#cupGradient)" stroke="#ddd" stroke-width="2" />
        <ellipse cx="250" cy="210" rx="38" ry="12" fill="{coffee_color}" />
        
        <!-- Espresso crema -->
        <ellipse cx="250" cy="210" rx="36" ry="10" fill="#C9A66B" opacity="0.7" />
        
        <!-- Cup handle -->
        <path d="M 295 215 C 315 215, 315 230, 295 230" fill="none" stroke="#ddd" stroke-width="2.5" />
        
        <!-- Espresso steam -->
        <path d="M 235 195 C 230 185, 240 175, 235 165" fill="none" stroke="#ddd" stroke-width="1.5" opacity="0.6" />
        <path d="M 250 195 C 245 180, 255 170, 250 155" fill="none" stroke="#ddd" stroke-width="1.5" opacity="0.6" />
        <path d="M 265 195 C 260 185, 270 175, 265 165" fill="none" stroke="#ddd" stroke-width="1.5" opacity="0.6" />
        
        <!-- Saucer -->
        <ellipse cx="250" cy="245" rx="60" ry="12" fill="url(#cupGradient)" stroke="#ddd" stroke-width="1.5" />
        """
    elif brewing_method == "Cold Brew":
        svg += f"""
        <!-- Brewing Method Label -->
        <text x="250" y="130" font-family="Arial" font-size="14" fill="#006241" font-weight="bold" text-anchor="middle">Cold Brew</text>
        
        <!-- Cold Brew glass -->
        <path d="M 220 160 L 210 260 L 290 260 L 280 160 Z" fill="url(#cupGradient)" stroke="#ddd" stroke-width="2" />
        <path d="M 222 170 L 214 260 L 286 260 L 278 170 Z" fill="{coffee_color}" opacity="0.9" />
        
        <!-- Ice cubes -->
        <rect x="230" y="180" width="15" height="15" rx="3" fill="white" opacity="0.7" />
        <rect x="255" y="195" width="18" height="18" rx="3" fill="white" opacity="0.7" />
        <rect x="240" y="220" width="12" height="12" rx="3" fill="white" opacity="0.7" />
        
        <!-- Straw -->
        <rect x="260" y="150" width="4" height="110" rx="2" fill="#E0E0E0" />
        
        <!-- Condensation -->
        <circle cx="217" cy="200" r="1" fill="#FFFFFF" opacity="0.8" />
        <circle cx="214" cy="220" r="1.2" fill="#FFFFFF" opacity="0.8" />
        <circle cx="215" cy="240" r="1" fill="#FFFFFF" opacity="0.8" />
        <circle cx="286" cy="190" r="1" fill="#FFFFFF" opacity="0.8" />
        <circle cx="288" cy="210" r="1.2" fill="#FFFFFF" opacity="0.8" />
        <circle cx="285" cy="230" r="1" fill="#FFFFFF" opacity="0.8" />
        """
    elif brewing_method == "Pour Over":
        svg += f"""
        <!-- Brewing Method Label -->
        <text x="250" y="130" font-family="Arial" font-size="14" fill="#006241" font-weight="bold" text-anchor="middle">Pour Over</text>
        
        <!-- Pour Over setup -->
        <path d="M 210 170 L 230 240 L 270 240 L 290 170 Z" fill="none" stroke="#ddd" stroke-width="2" />
        <ellipse cx="250" cy="240" rx="30" ry="10" fill="url(#cupGradient)" stroke="#ddd" stroke-width="1.5" />
        <path d="M 220 240 C 220 270, 280 270, 280 240" fill="url(#cupGradient)" stroke="#ddd" stroke-width="1.5" />
        <ellipse cx="250" cy="240" rx="25" ry="8" fill="{coffee_color}" />
        
        <!-- Pour Over filter -->
        <path d="M 210 170 L 230 240 L 270 240 L 290 170 Z" fill="white" fill-opacity="0.2" />
        
        <!-- Coffee stream -->
        <path d="M 250 180 C 248 190, 252 200, 250 210" stroke="{coffee_color}" stroke-width="2" fill="none" />
        
        <!-- Steam -->
        <path d="M 235 230 C 230 220, 240 210, 235 200" fill="none" stroke="#ddd" stroke-width="1.5" opacity="0.5" />
        <path d="M 250 230 C 245 215, 255 205, 250 190" fill="none" stroke="#ddd" stroke-width="1.5" opacity="0.5" />
        <path d="M 265 230 C 260 220, 270 210, 265 200" fill="none" stroke="#ddd" stroke-width="1.5" opacity="0.5" />
        """
    elif brewing_method == "French Press":
        svg += f"""
        <!-- Brewing Method Label -->
        <text x="250" y="130" font-family="Arial" font-size="14" fill="#006241" font-weight="bold" text-anchor="middle">French Press</text>
        
        <!-- French Press container -->
        <rect x="220" y="160" width="60" height="90" rx="3" ry="3" fill="url(#cupGradient)" stroke="#ddd" stroke-width="2" />
        <rect x="225" y="165" width="50" height="80" fill="{coffee_color}" />
        
        <!-- French Press plunger -->
        <line x1="250" y1="145" x2="250" y2="165" stroke="#aaa" stroke-width="2" />
        <rect x="235" y="145" width="30" height="5" rx="2" ry="2" fill="#aaa" />
        
        <!-- French Press handle -->
        <path d="M 280 180 C 295 180, 295 210, 280 210" fill="none" stroke="#ddd" stroke-width="2.5" />
        
        <!-- French Press frame -->
        <rect x="220" y="160" width="60" height="10" fill="none" stroke="#aaa" stroke-width="1" />
        <rect x="220" y="240" width="60" height="10" fill="none" stroke="#aaa" stroke-width="1" />
        <line x1="220" y1="170" x2="220" y2="240" stroke="#aaa" stroke-width="1" />
        <line x1="280" y1="170" x2="280" y2="240" stroke="#aaa" stroke-width="1" />
        
        <!-- Steam -->
        <path d="M 235 160 C 230 150, 240 140, 235 130" fill="none" stroke="#ddd" stroke-width="1.5" opacity="0.6" />
        <path d="M 250 160 C 245 145, 255 135, 250 120" fill="none" stroke="#ddd" stroke-width="1.5" opacity="0.6" />
        <path d="M 265 160 C 260 150, 270 140, 265 130" fill="none" stroke="#ddd" stroke-width="1.5" opacity="0.6" />
        """
    elif brewing_method == "Chemex":
        svg += f"""
        <!-- Brewing Method Label -->
        <text x="250" y="130" font-family="Arial" font-size="14" fill="#006241" font-weight="bold" text-anchor="middle">Chemex</text>
        
        <!-- Chemex container -->
        <path d="M 230 160 L 220 180 L 220 230 C 220 250, 280 250, 280 230 L 280 180 L 270 160 Z" fill="url(#cupGradient)" stroke="#ddd" stroke-width="2" />
        <path d="M 225 180 L 225 230 C 225 245, 275 245, 275 230 L 275 180 Z" fill="{coffee_color}" opacity="0.9" />
        
        <!-- Chemex belt -->
        <path d="M 230 200 C 230 205, 270 205, 270 200" fill="none" stroke="#C19A6B" stroke-width="10" />
        
        <!-- Chemex filter -->
        <path d="M 230 160 L 220 180 L 220 200 L 280 200 L 280 180 L 270 160 Z" fill="white" fill-opacity="0.3" stroke="#eee" stroke-width="1" />
        
        <!-- Steam -->
        <path d="M 240 160 C 235 145, 245 135, 240 120" fill="none" stroke="#ddd" stroke-width="1.5" opacity="0.5" />
        <path d="M 250 160 C 245 140, 255 130, 250 110" fill="none" stroke="#ddd" stroke-width="1.5" opacity="0.5" />
        <path d="M 260 160 C 255 145, 265 135, 260 120" fill="none" stroke="#ddd" stroke-width="1.5" opacity="0.5" />
        """
    else:  # Default coffee mug for other brewing methods like Drip, AeroPress
        svg += f"""
        <!-- Brewing Method Label -->
        <text x="250" y="130" font-family="Arial" font-size="14" fill="#006241" font-weight="bold" text-anchor="middle">{brewing_method}</text>
        
        <!-- Coffee mug -->
        <ellipse cx="250" cy="200" rx="50" ry="18" fill="url(#cupGradient)" stroke="#ddd" stroke-width="2" />
        <path d="M 200 200 C 200 250, 300 250, 300 200" fill="url(#cupGradient)" stroke="#ddd" stroke-width="2" />
        <ellipse cx="250" cy="200" rx="45" ry="15" fill="{coffee_color}" />
        
        <!-- Mug handle -->
        <path d="M 300 210 C 325 210, 325 235, 300 235" fill="none" stroke="#ddd" stroke-width="3" />
        
        <!-- Steam -->
        <path d="M 230 180 C 225 165, 235 155, 230 140" fill="none" stroke="#ddd" stroke-width="1.5" opacity="0.6" />
        <path d="M 250 180 C 245 160, 255 150, 250 130" fill="none" stroke="#ddd" stroke-width="1.5" opacity="0.6" />
        <path d="M 270 180 C 265 165, 275 155, 270 140" fill="none" stroke="#ddd" stroke-width="1.5" opacity="0.6" />
        """
    
    # Add coffee surface details
    if brewing_method != "Cold Brew":
        svg += f"""
        <!-- Coffee surface details -->
        <ellipse cx="250" cy="200" rx="43" ry="13" fill="{coffee_color}" opacity="0.7" />
        """
    
    # Add Starbucks logo
    svg += f"""
    <!-- Starbucks logo -->
    <circle cx="250" cy="50" r="25" fill="#006241" />
    <circle cx="250" cy="50" r="22" fill="white" />
    <circle cx="250" cy="50" r="19" fill="#006241" />
    
    <!-- Simplified mermaid in logo -->
    <circle cx="250" cy="50" r="13" fill="white" opacity="0.4" />
    """
    
    # Add recipe name and info
    svg += f"""
    <!-- Recipe name and info -->
    <rect x="50" y="300" width="400" height="60" rx="5" ry="5" fill="#006241" opacity="0.1" />
    <text x="250" y="325" font-family="Arial" font-size="18" font-weight="bold" fill="#006241" text-anchor="middle">{recipe_name}</text>
    <text x="250" y="345" font-family="Arial" font-size="12" fill="#666" text-anchor="middle">{roast_profile} • {brewing_method}</text>
    
    <!-- Starbucks copyright -->
    <text x="250" y="380" font-family="Arial" font-size="8" fill="#888" text-anchor="middle">© Starbucks Coffee • AI Generated Recipe</text>
    """
    
    # Close SVG
    svg += """
    </svg>
    """
    
    # Convert SVG to base64 for HTML embedding
    svg_bytes = svg.encode('utf-8')
    b64 = base64.b64encode(svg_bytes).decode('utf-8')
    
    return f"data:image/svg+xml;base64,{b64}"