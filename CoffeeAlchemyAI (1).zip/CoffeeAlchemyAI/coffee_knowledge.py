import re

def extract_coffee_knowledge(extracted_text):
    """
    Extract relevant coffee knowledge from the text.
    
    Args:
        extracted_text (str): Text extracted from the PDF
        
    Returns:
        str: Extracted coffee knowledge
    """
    # Combine all relevant coffee information from the text
    coffee_knowledge = []
    
    # Try to extract coffee growing regions info
    regions_info = get_coffee_regions_info(extracted_text)
    if regions_info:
        coffee_knowledge.append(regions_info)
    
    # Try to extract roast profiles info
    roast_profiles_info = get_roast_profiles_info(extracted_text)
    if roast_profiles_info:
        coffee_knowledge.append(roast_profiles_info)
    
    # Try to extract brewing methods info
    brewing_info = get_brewing_methods_info(extracted_text)
    if brewing_info:
        coffee_knowledge.append(brewing_info)
    
    # Try to extract processing methods info
    processing_info = get_processing_methods_info(extracted_text)
    if processing_info:
        coffee_knowledge.append(processing_info)
    
    # Combine all the extracted knowledge
    return "\n\n".join(coffee_knowledge)

def get_coffee_regions_info(text):
    """
    Extract information about coffee growing regions.
    
    Args:
        text (str): Extracted text from the PDF
        
    Returns:
        str: Information about coffee growing regions
    """
    # Try to find the coffee regions section
    regions_pattern = r"Coffee-Growing Regions.*?(?=\n\n\S)"
    regions_match = re.search(regions_pattern, text, re.DOTALL)
    
    latin_america_pattern = r"Latin America.*?(?=\n\n)"
    africa_pattern = r"Africa.*?(?=\n\n)"
    asia_pacific_pattern = r"Asia/Pacific.*?(?=\n\n)"
    
    regions_info = []
    
    # If the main section is found, extract it
    if regions_match:
        regions_info.append("# Coffee Growing Regions")
        regions_info.append(regions_match.group(0).strip())
    
    # Otherwise, try to extract individual region descriptions
    else:
        regions_info.append("# Coffee Growing Regions")
        
        latin_match = re.search(latin_america_pattern, text, re.DOTALL)
        if latin_match:
            regions_info.append("## Latin America")
            regions_info.append(latin_match.group(0).strip())
        
        africa_match = re.search(africa_pattern, text, re.DOTALL)
        if africa_match:
            regions_info.append("## Africa")
            regions_info.append(africa_match.group(0).strip())
        
        asia_match = re.search(asia_pacific_pattern, text, re.DOTALL)
        if asia_match:
            regions_info.append("## Asia/Pacific")
            regions_info.append(asia_match.group(0).strip())
    
    # If no information was found, return empty string
    if len(regions_info) <= 1:
        return ""
    
    return "\n\n".join(regions_info)

def get_roast_profiles_info(text):
    """
    Extract information about coffee roast profiles.
    
    Args:
        text (str): Extracted text from the PDF
        
    Returns:
        str: Information about coffee roast profiles
    """
    # Try to find the roasting section
    roasting_pattern = r"Roasting Coffee.*?(?=\n\n\S)"
    roasting_match = re.search(roasting_pattern, text, re.DOTALL)
    
    if roasting_match:
        roast_info = ["# Coffee Roast Profiles", roasting_match.group(0).strip()]
        return "\n\n".join(roast_info)
    
    # If specific section not found, try to extract individual roast profile descriptions
    blonde_pattern = r"Blonde-roasted coffees.*?(?=\n)"
    medium_pattern = r"Medium-roasted coffees.*?(?=\n)"
    dark_pattern = r"Dark-roasted coffees.*?(?=\n)"
    
    roast_info = ["# Coffee Roast Profiles"]
    
    blonde_match = re.search(blonde_pattern, text)
    if blonde_match:
        roast_info.append("## Blonde Roast")
        roast_info.append(blonde_match.group(0).strip())
    
    medium_match = re.search(medium_pattern, text)
    if medium_match:
        roast_info.append("## Medium Roast")
        roast_info.append(medium_match.group(0).strip())
    
    dark_match = re.search(dark_pattern, text)
    if dark_match:
        roast_info.append("## Dark Roast")
        roast_info.append(dark_match.group(0).strip())
    
    # If no information was found, return empty string
    if len(roast_info) <= 1:
        return ""
    
    return "\n\n".join(roast_info)

def get_brewing_methods_info(text):
    """
    Extract information about coffee brewing methods.
    
    Args:
        text (str): Extracted text from the PDF
        
    Returns:
        str: Information about coffee brewing methods
    """
    # Try to find the brewing section
    brewing_pattern = r"Brewing (?:and|&) Tasting Coffee.*?(?=\n\n\S)"
    brewing_match = re.search(brewing_pattern, text, re.DOTALL)
    
    if brewing_match:
        brewing_info = ["# Coffee Brewing Methods", brewing_match.group(0).strip()]
        return "\n\n".join(brewing_info)
    
    # Try to find any brewing instructions
    pour_over_pattern = r"(?:Pour[- ]Over|Manual Brew).*?(?=\n\n\S)"
    french_press_pattern = r"(?:French Press).*?(?=\n\n\S)"
    cold_brew_pattern = r"(?:Cold Brew).*?(?=\n\n\S)"
    
    brewing_info = ["# Coffee Brewing Methods"]
    
    pour_over_match = re.search(pour_over_pattern, text, re.DOTALL)
    if pour_over_match:
        brewing_info.append("## Pour Over")
        brewing_info.append(pour_over_match.group(0).strip())
    
    french_press_match = re.search(french_press_pattern, text, re.DOTALL)
    if french_press_match:
        brewing_info.append("## French Press")
        brewing_info.append(french_press_match.group(0).strip())
    
    cold_brew_match = re.search(cold_brew_pattern, text, re.DOTALL)
    if cold_brew_match:
        brewing_info.append("## Cold Brew")
        brewing_info.append(cold_brew_match.group(0).strip())
    
    # If no information was found, return empty string
    if len(brewing_info) <= 1:
        return """
# Coffee Brewing Methods

## Pour Over
Pour-over brewing involves pouring hot water over coffee grounds in a filter. The water drains through the coffee and filter into a carafe or mug. This method allows precise control over brewing time and coffee-to-water ratio, typically producing a clean, clear cup.

## French Press
French press brewing involves steeping coffee grounds in hot water, then pressing a metal mesh filter down to separate the grounds from the coffee. This method produces a full-bodied cup with more oils and fine particles.

## Espresso
Espresso is brewed by forcing hot water through finely-ground coffee under high pressure. This produces a concentrated coffee with a layer of crema on top.

## Cold Brew
Cold brew is made by steeping coffee grounds in cold water for 12-24 hours. This produces a smooth, less acidic coffee concentrate that can be diluted with water or milk.

## Drip Coffee
Drip coffee is made by letting hot water drip through coffee grounds in a filter. The water flows through the coffee and filter by gravity, extracting flavors as it passes through.

## AeroPress
AeroPress uses pressure to force hot water through coffee grounds. It's a versatile method that can produce coffee similar to espresso or drip coffee, depending on the technique.

## Chemex
Chemex is a pour-over method using a special hourglass-shaped vessel and thicker paper filters. It produces a very clean, bright cup with clear flavors.
"""
    
    return "\n\n".join(brewing_info)

def get_processing_methods_info(text):
    """
    Extract information about coffee processing methods.
    
    Args:
        text (str): Extracted text from the PDF
        
    Returns:
        str: Information about coffee processing methods
    """
    # Try to find the processing section
    processing_pattern = r"Processing.*?(?=\n\n\S)"
    processing_match = re.search(processing_pattern, text, re.DOTALL)
    
    if processing_match:
        processing_info = ["# Coffee Processing Methods", processing_match.group(0).strip()]
        return "\n\n".join(processing_info)
    
    # Try to find individual processing methods
    washed_pattern = r"(?:Washed Process).*?(?=\n\d)"
    semi_washed_pattern = r"(?:Semi-Washed Process).*?(?=\n\d)"
    natural_pattern = r"(?:Natural Process).*?(?=\n\n\S)"
    
    processing_info = ["# Coffee Processing Methods"]
    
    washed_match = re.search(washed_pattern, text, re.DOTALL)
    if washed_match:
        processing_info.append("## Washed Process")
        processing_info.append(washed_match.group(0).strip())
    
    semi_washed_match = re.search(semi_washed_pattern, text, re.DOTALL)
    if semi_washed_match:
        processing_info.append("## Semi-Washed Process")
        processing_info.append(semi_washed_match.group(0).strip())
    
    natural_match = re.search(natural_pattern, text, re.DOTALL)
    if natural_match:
        processing_info.append("## Natural Process")
        processing_info.append(natural_match.group(0).strip())
    
    # If no information was found, return empty string
    if len(processing_info) <= 1:
        return ""
    
    return "\n\n".join(processing_info)
